(function() {

if (! GrpL.fileio) {
    GrpL.fileio = {};
}

// Symbolic constants for text file IO functions

GrpL.fileio.FILEIO_APPEND_NEWLINE = "APPEND_NL";
GrpL.fileio.FILEIO_DONT_APPEND_NEWLINE = "DONT_APPEND_NL";

})();
