(function() {

GrpL.C.APP_ID               = "IDSN";

})();


