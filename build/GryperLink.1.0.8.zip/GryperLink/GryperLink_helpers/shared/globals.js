(function() {

GrpL.C.DIRNAME_PREFERENCES  = "GryperLink";
GrpL.C.FILENAME_PREFERENCES = "GryperLinkPreferences.json";

GrpL.C.LOG_NONE                      = 0;
GrpL.C.LOG_ERROR                     = 1;
GrpL.C.LOG_WARN                      = 2;
GrpL.C.LOG_WARNING                   = GrpL.C.LOG_WARN;
GrpL.C.LOG_NOTE                      = 3;
GrpL.C.LOG_TRACE                     = 4;

/* Add any global constants */

})();


